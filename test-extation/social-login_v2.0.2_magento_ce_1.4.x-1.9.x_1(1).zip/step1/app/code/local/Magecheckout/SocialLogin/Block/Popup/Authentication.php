<?php

class Magecheckout_SocialLogin_Block_Popup_Authentication extends Mage_Customer_Block_Form_Login
{

}
