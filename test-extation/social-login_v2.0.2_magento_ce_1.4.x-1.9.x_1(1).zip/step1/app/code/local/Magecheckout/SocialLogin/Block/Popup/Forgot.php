<?php


class Forgot extends Magecheckout_SocialLogin_Block_Sociallogin
{

}
