<?php

class Magecheckout_SocialLogin_Block_Popup_Create extends Mage_Customer_Block_Form_Register
{

}
